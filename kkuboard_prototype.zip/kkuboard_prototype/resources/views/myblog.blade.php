<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Blog</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body style="background-color:#efefef;">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
        integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy"
        crossorigin="anonymous"></script>
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-black fixed-top"">
        <div class=" container-fluid">
        <!-- logo -->
        <a class="navbar-brand img-fluid" href="#">
            <img src="/images/logo.png" alt="" width="80" height="60">
        </a>
        <!-- menu -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a href="#" class="nav-link">หน้าหลัก</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">หมวดหมู่</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">บล็อกของฉัน</a>
                </li>
            </ul>
            <form class="d-flex" role="search">
                <input class="form-control me-1" type="search" placeholder="ค้นหาด้วยชื่อบล็อก" aria-label="Search">
                <button class="btn btn-outline-light me-4" type="submit">ค้นหา</button>
            </form>
            <br>
            <button class="btn btn-outline-danger rounded-5" type="button">ออกจากระบบ</button>
        </div>
        </div>
    </nav>

    <!-- blog box -->
    <div class="p-5 w-75 container text-dark-emphasis bg-white rounded-3" style="margin-top:130px; margin-bottom:50px">
        <div class="container" style="color: #000">
            <div class="d-flex justify-content-between">
                <!-- title -->
                <h3>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, dolore?</h3>
                <!-- filter -->
                <div class="dropdown">
                    <button class="btn btn-outline-dark rounded-5 dropdown-toggle" type="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        จัดการบล็อก
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">แก้ไขบล็อก</a></li>
                        <li><a class="dropdown-item" href="#">ลบบล็อก</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- category -->
        <button class="btn btn-dark w-25 rounded-5" type="button">
            <h5>Lorem, ipsum.</h5>
        </button>
        <br><br>
        <!-- content -->
        <p class="lead">
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ea dolor neque, rerum vero nihil explicabo
            consequuntur esse cumque reprehenderit eaque, quidem nostrum sequi necessitatibus iure ab alias quas dolore
            provident sed! Eaque cumque sit et sint, aliquid modi provident hic maxime accusantium veritatis in, ullam
            placeat sunt nobis illum iusto facilis perspiciatis veniam quaerat porro, molestiae tempore dolores nemo
            repudiandae. A quae quis, nesciunt similique iusto ab facere nobis veritatis?
        </p>
        <!-- picture -->
        <div class="text-center">
            <img class="img-fluid rounded-3 w-50" src="/images/demopic.jpg" alt="">
        </div>
        <!-- username & upload date -->
        <br>
        <p>username - 28 พฤษภาคม 2022</p>
        <!-- add comment -->
        <form action="">
            <ul class="list-group">
                <li class="list-group-item">
                    <textarea type="text" class="form-control" placeholder="แสดงความคิดเห็นของคุณ"></textarea>
                </li>
                <li class="list-group-item">
                    <div class="text-end">
                        <input type="submit" class="btn btn-outline-dark rounded-5" value="แสดงความคิดเห็น">
                    </div>
                </li>
            </ul>
        </form>
        <br>
        <!-- comments -->
        <ul class="list-group list-group-flush">
            <!-- comment -->
            <li class="list-group-item">
                <!-- content -->
                <p class="lead">
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, porro!
                </p>
                <!-- username & upload date-->
                 <p>username - 28 พฤษภาคม 2022</p>
            </li>
            <li class="list-group-item">
                <p class="lead">
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Natus in, reprehenderit pariatur suscipit tenetur nostrum veniam et perferendis omnis quidem!
                </p>
                 <p>username - 28 พฤษภาคม 2022</p>
            </li>
            <li class="list-group-item">
                <p class="lead">
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, porro!
                </p>
                 <p>username - 28 พฤษภาคม 2022</p>
            </li>
        </ul>
    </div>
</body>

</html>